import { MDToPdfViewComponent } from './_components/view'

export default function MdToPdfPage() {
  return <MDToPdfViewComponent />
}
