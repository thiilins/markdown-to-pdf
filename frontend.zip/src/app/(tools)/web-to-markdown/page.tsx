import { WebToMarkdownViewComponent } from './_components/view'

export default function WebToMarkdownPage() {
  return <WebToMarkdownViewComponent />
}

