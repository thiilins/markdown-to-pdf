import { GistExplorerViewComponent } from './_components/view'

export default function GistExplorerPage() {
  return <GistExplorerViewComponent />
}
