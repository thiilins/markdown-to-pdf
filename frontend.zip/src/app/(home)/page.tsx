import { HomeViewComponent } from './_components/view'
export default function Home() {
  return <HomeViewComponent />
}
