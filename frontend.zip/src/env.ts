export const ENVIROMENT = {
  API_URL: process.env.NEXT_PUBLIC_API_URL || null,
  ENABLE_EXPORT: process.env.NEXT_PUBLIC_ENABLE_EXPORT_URL === 'true' || false,
}
