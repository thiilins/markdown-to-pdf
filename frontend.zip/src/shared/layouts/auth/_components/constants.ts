// ;('authenticated', 'loading', 'unauthenticated')

export const INVALID_AUTH_STATUS = ['loading', 'unauthenticated']
